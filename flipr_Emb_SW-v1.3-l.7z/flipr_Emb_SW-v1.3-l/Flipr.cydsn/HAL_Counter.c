/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file HAL_Counter.h
 * @brief Counter
 *
 *      This application manage timer for delay non-blocking
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */
#include "HAL_Counter.h"


uint8 _flagCounterEnded=0;


CY_ISR(Counter_Int_Handler){
     if((COUNTER_GetInterruptSource()&COUNTER_INTR_MASK_TC) == COUNTER_INTR_MASK_TC){
        COUNTER_ClearInterrupt(COUNTER_INTR_MASK_TC);
        _flagCounterEnded=1;
    }
  
}
void Hal_Counter_setPrescaler(uint32 value){
    COUNTER_SetPrescaler(value);
}

uint8 Hal_Counter_isEnded(void){
    return _flagCounterEnded;
}

void Hal_Counter_Init(uint32 prescaler, uint32 int_mask){
    _flagCounterEnded=0;

    COUNTER_Init();
    COUNTER_SetInterruptMode(int_mask);
    COUNTER_Enable();
    COUNTER_Start();
    Hal_Counter_setPrescaler(prescaler);

    ISR_Counter_StartEx(Counter_Int_Handler);
}

void Hal_Counter_Stop(void){
    COUNTER_Stop();
    ISR_Counter_Stop();
    _flagCounterEnded=0;

}


/* [] END OF FILE */
