/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file HAL_DS18B20.h
 * @brief DS18B20
 *
 *      Service to measure battery level
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include "HAL_DS18B20.h"


uint8 Hal_DS18_Init(void){
    
    return OneWire_BusReset();
}



void Hal_DS18_ReadRom(uint8 rom[8]){
    uint8 i=0;
    
    OneWire_Write8(0x33);
    while(i<8){
        rom[i++] = OneWire_Read8();
    }
}



void Hal_DS18_ReadReg(uint8 reg[9]){
    uint8 i=0;
    OneWire_Write8(0xbe);
    
    while(i<9){
        reg[i++] = OneWire_Read8();
    }
}


uint8 Hal_DS18_doAcq(void){
    uint8 reg[9] = {0x0};
    uint8 rom[8] = {0x0};
    uint32 p = 0;
    
    if (Hal_DS18_Init() != 0){
        return 1;
    }
    
    Hal_DS18_ReadRom(rom);
    
    
    OneWire_Write8(0x44);

    return 0;
    
}


uint16 Hal_DS18_ReadTemp(void){
    uint8 reg[9] = {0x0};
    uint8 rom[8] = {0x0};
    
    if (Hal_DS18_Init() != 0){
        return 1;
    }
   
    Hal_DS18_ReadRom(rom);
    
    Hal_DS18_ReadReg(reg);
    
    return (reg[0] + ((reg[1]&0x7)<<8));
}



void Hal_DS18_SetResolution(uint8 r1, uint8 r2){
    OneWire_Write8(0x4e); // Write in registers
    OneWire_Write8(0x00); // TH register
    OneWire_Write8(0x00); // TL register
    OneWire_Write8((r1<<6) | (r2<<5)); // Config register
    
}

/* [] END OF FILE */
