/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file DRV_OneWire.h
 * @brief OneWire
 *
 *      Drivers for comunication bus 1-Wire
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include "DRV_OneWire.h"



uint8 OneWire_R_Bit() //***  Read a single bit off the 1-WIRE bus. ***
    {
        uint8 res = 0;
        CyDelayUs(Tinact);  
       
        Pin_TEMP_SetDriveMode(Pin_TEMP_DM_OD_LO);
        
        Pin_TEMP_Write(1);       
        CyDelayUs(1);
        Pin_TEMP_Write(0);
        CyDelayUs(5);   
        
        Pin_TEMP_SetDriveMode(Pin_TEMP_DM_DIG_HIZ);

        res = Pin_TEMP_Read();
        
        CyDelayUs(60);
	    return res;  
	}
    
    


void OneWire_W_Bit(uint8 payload) // Write a single bit to the 1-WIRE bus. 
    {
	    CyDelayUs(Tinact);  
        Pin_TEMP_SetDriveMode(Pin_TEMP_DM_OD_LO);
        
	    Pin_TEMP_Write(0);     
	        if(payload==0)		CyDelayUs(TMtr0); 
	        else     		    CyDelayUs(TMtr1); 
	    Pin_TEMP_Write(1);     
        CyDelayUs(60);
    }

    
uint8 OneWire_BusReset() 
    {
        uint8 BusPin=0 ;      
        Pin_TEMP_SetDriveMode(Pin_TEMP_DM_OD_LO);
        Pin_TEMP_Write(0);    
	    CyDelayUs(RST_MAX);
     
        Pin_TEMP_SetDriveMode(Pin_TEMP_DM_DIG_HIZ);
        CyDelayUs(5);  
        
        if (Pin_TEMP_Read()==0x00)  	return(0xFF);   
        
        CyDelayUs(55);     
        BusPin = Pin_TEMP_Read();   
        
        CyDelayUs(480);     
        
return(BusPin);       
    }
 

void OneWire_Write8(uint8 payload) //Write a byte to the slave.
    {
	    uint8 BitPayload,  shiftcount;
	    for (shiftcount=0; shiftcount<=7;shiftcount++) 
        {
            BitPayload = (payload >> shiftcount) & 0x01; 
            OneWire_W_Bit(BitPayload);
        }
    }  
    

uint8 OneWire_Read8() //Read 8 bits "clocked" out by the slave. 
{
	uint8 IncomingByte=0, shiftcount=0 ;
	for (shiftcount=0; shiftcount<=7; shiftcount++) 
    {
       IncomingByte |= (OneWire_R_Bit())<<shiftcount;
    }
    return(IncomingByte);
}
   

/* [] END OF FILE */
