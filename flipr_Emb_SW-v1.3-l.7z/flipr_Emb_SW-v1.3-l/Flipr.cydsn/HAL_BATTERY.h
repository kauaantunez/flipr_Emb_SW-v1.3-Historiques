/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file HAL_BATTERY.h
 * @brief BATTERY
 *
 *      Service to measure battery level
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#ifndef HAL_BATT_H
#define HAL_BATT_H
    
#include <project.h>
#include "common.h"

#define ADC_VREF_MASK               (0x000000F0Lu)
    
int32 Hal_BatteryMeasure(void);

#endif

/* [] END OF FILE */
