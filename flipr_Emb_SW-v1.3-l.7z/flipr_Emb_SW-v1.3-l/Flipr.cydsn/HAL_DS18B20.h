/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file HAL_DS18B20.h
 * @brief DS18B20
 *
 *      Service to communicate with sensor DS18B20
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */
#ifndef HAL_DS18B20_H
#define HAL_DS18B20_H
    
#include <project.h>
#include "common.h" 
#include "DRV_OneWire.h"   

uint8 Hal_DS18_Init(void);
void Hal_DS18_ReadRom(uint8 rom[8]);
uint8 Hal_DS18_doAcq(void);
void Hal_DS18_ReadReg(uint8 reg[9]);
uint16 Hal_DS18_ReadTemp(void);
void Hal_DS18_setResolution(uint8 r1, uint8 r2);


#endif
/* [] END OF FILE */
