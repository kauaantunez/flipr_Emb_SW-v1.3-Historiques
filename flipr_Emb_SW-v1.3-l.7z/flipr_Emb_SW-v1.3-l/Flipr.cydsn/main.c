/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Myfox written approval
 *
 * @file main.c
 * @brief Main 
 *
 *       Supervisor Flipr
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include <project.h>

#include "common.h"
#include <stdio.h>

#include "ASW_TestMode.h"
#include "DRV_WdtTimer.h"
#include "HAL_UartSfx.h"
#include "HAL_DS18B20.h"
#include "HAL_BATTERY.h"
#include "HAL_Counter.h"
#include "ASW_BLE.h"


#define BANC_TEST_BETA 1

volatile uint16_t _u16MainFlags;
uint16_t _u16MainFreqOrp;
uint8_t _u8MainInitSleep;

CY_ISR(Condt_Int_Handler){
    Pin_condt_ClearInterrupt();
    _u16MainFreqOrp+=1;
}


void init(){
    uint8_t id[8];
    uint8 pac[16] = {0};
    int8_t device_name[20];
    CYBLE_API_RESULT_T eBle_ApiResult;
    
   
    _u8CommonMode=MODE_NORMAL;
    
    /* Program a futur measure and update BLE characteristic */
    _u16MainFlags =  FLAG_ALL_MEASURES|FLAG_SFX|FLAG_BLE_DEVICE|FLAG_BLE_MEASURE;
    
 
    eBle_ApiResult = CyBle_Start(Asw_Ble_StackEventHandler);

    if(eBle_ApiResult != CYBLE_ERROR_OK)
    {
        /* BLE stack initialization failed */
        CYASSERT(0);
    }
    
    CyDelay(1000);
    
    _u8MainInitSleep = 0;
    

    
    /* Reading of ID Sigfox and push on device name */
    UART_rx_SetDriveMode(UART_rx_DM_RES_DWN);
    UART_tx_SetDriveMode(UART_tx_DM_RES_DWN);
    
    ANALOG_EN_Write(SWITCH_ON);
    SIGFOX_EN_Write(SWITCH_ON);
    CyDelay(200);
    
    Hal_Uart_InitComm();     
    Hal_Sfx_ReadId(id);
    CyDelay(200);
    Hal_Sfx_ReadPac(pac);
    
    sprintf(device_name, "Flipr %s", id);
    CyBle_GapSetLocalName(device_name);
            
    ANALOG_EN_Write(SWITCH_OFF);
    SIGFOX_EN_Write(SWITCH_OFF);
    
    UART_rx_SetDriveMode(UART_rx_DM_ALG_HIZ);
    UART_tx_SetDriveMode(UART_tx_DM_ALG_HIZ);
            
       
    /* Configuration Watchdog */
    Drv_WdtTimer_Start(WDT_COUNT1_MATCH_RESET, CY_SYS_WDT_MODE_RESET, NO_MODE);
}




int main()
{
    uint16 battery = 0x0;
    uint16 conductivite = 0x0;
    uint16 temperature = 0x0;
    uint16 ph = 0x0;
    uint16 orp = 0x0;
    uint16 id_mesure = 0;
    uint8 counter = 0x0;
    
    CyGlobalIntEnable;
    
    modeOff();
    
#ifdef BANC_TEST_BETA
    SIGFOX_EN_Write(SWITCH_ON);
    CyDelay(10000);
    SIGFOX_EN_Write(SWITCH_OFF);
#endif

    Pin_TestMode_SetDriveMode(Pin_TestMode_DM_ALG_HIZ);
    
    init();

    CyDelay(1000); //delay before the first mesure

    for(;;)
    { 
       CyBle_ProcessEvents();
            
        if (_u8CommonMode == MODE_VEILLE) {
            modeOff();
            Asw_Ble_SleepMode();
        }
        else {
        
            if((_u16MainFlags&FLAG_ALL_ACTIONS) >  FLAG_NO_ACTIONS){
                
                _u8MainInitSleep = 0;
                
                ANALOG_EN_Write(SWITCH_ON);

                /* Conductivity measure */
                if((_u16MainFlags&FLAG_CONDT) > FLAG_NO_ACTIONS){
                    
                    if((_u16MainFlags&FLAG_CONDT_INIT) == FLAG_CONDT_INIT){  
                        
                        /* Increase ID mesures */
                        if(id_mesure < 0xffff){
                            id_mesure += 1;
                        }else{
                            id_mesure=0;
                        }
           
                        
                        COND_switch_Write(SWITCH_ON);
                        _u16MainFlags &= ~FLAG_CONDT_INIT;
                        _u16MainFreqOrp=0;
                        Int_condt_StartEx(Condt_Int_Handler);
                        counter = 0;
                        Pin_condt_SetDriveMode(Pin_condt_DM_RES_DWN);
   
                        EN_TIMER_1S();
                    }
                    else {
                        if(TIMER_END()){
                            Int_condt_Stop();
                            conductivite = (uint16_t) _u16MainFreqOrp/1.04856;
                            
                            if(conductivite > 0 || counter > 1){
                                counter=0;
                                COND_switch_Write(SWITCH_OFF);
                                _u16MainFlags &= ~FLAG_CONDT_ACQ;
                                Pin_condt_SetDriveMode(Pin_condt_DM_DIG_HIZ);
                                TIMER_STOP();
                            }else{
                                counter += 1;
                                _u16MainFreqOrp=0;
                                COND_switch_Write(SWITCH_ON);
                                Int_condt_StartEx(Condt_Int_Handler);
                                Pin_condt_SetDriveMode(Pin_condt_DM_RES_DWN);
                                EN_TIMER_1S();
                            }
                                
                        }
                    }
                }
                
                /* Temperature measure */
                else if((_u16MainFlags&FLAG_TEMPERATURE)> FLAG_NO_ACTIONS){
                    
                    if((_u16MainFlags&FLAG_TEMPERATURE_INIT) == FLAG_TEMPERATURE_INIT){
                        counter= 0;
                        _u16MainFlags &= ~FLAG_TEMPERATURE_INIT;

                        CyDelay(100);
                        EN_TEMP_Write(SWITCH_ON);
                        ANALOG_EN_Write(SWITCH_OFF);
                        
                        
                        EN_TIMER_524MS();

                    }
                    else if((_u16MainFlags&FLAG_TEMPERATURE_ACQ) == FLAG_TEMPERATURE_ACQ){
                        if(TIMER_END()){                      
                            _u16MainFlags &= ~FLAG_TEMPERATURE_ACQ;
                            TIMER_STOP();
                            Hal_DS18_doAcq();
                            EN_TIMER_2S();
                        }
                    }
                    else{
                        if(TIMER_END()){  
                            if(OneWire_R_Bit()==1 || counter >= 3){
                                counter = 0;
                                _u16MainFlags &= ~FLAG_TEMPERATURE_READ;
                                TIMER_STOP();
                               
                                temperature = Hal_DS18_ReadTemp();
                                EN_TEMP_Write(SWITCH_OFF);
                            }else{
                                counter += 1;
                            }
                            
                        }
                        
                    }
                }
                
                  /* ORP measure */  
                else if((_u16MainFlags&FLAG_ORP) > FLAG_NO_ACTIONS){
      
                    if((_u16MainFlags&FLAG_ORP_INIT) == FLAG_ORP_INIT){
                        
                        _u16MainFlags &= ~FLAG_ORP_INIT;
                        PH_switch_Write(SWITCH_OFF);
                        ORP_switch_Write(SWITCH_ON);
                        counter=0;
                        ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_INTERNAL1024;
                        
                        Drv_WdtTimer_Start(1,CY_SYS_WDT_MODE_INT,NO_MODE);//60s WDT timer
                        Asw_Ble_SleepMode();
          
                    }
                    else{

                        if(Drv_WdtTimer_isEnded()){
                            _u16MainFlags &= ~FLAG_ORP_ACQ;
                            
                            Drv_WdtTimer_Start(60,CY_SYS_WDT_MODE_RESET,NO_MODE);//reconfigure reset in 2min if problem
                            
                            counter = 0;
                            ADC_Start();
                        	ADC_StartConvert();
                        	ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
                    
                            orp = ADC_GetResult16(ADC_ORP_CHANNEL);

                            ORP_switch_Write(SWITCH_OFF);
                            ADC_Stop();
                        }else{
                            Asw_Ble_SleepMode();
                        }

                         
                    }
                    
                    
                   
                }

                     /* PH measure */
                else if((_u16MainFlags&FLAG_PH) > FLAG_NO_ACTIONS){
      
                    if((_u16MainFlags&FLAG_PH_INIT) == FLAG_PH_INIT){
                        _u16MainFlags &= ~FLAG_PH_INIT;

                        ADC_Start();
                        ORP_switch_Write(SWITCH_OFF);
                        PH_switch_Write(SWITCH_ON);
                   
                        ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_INTERNAL1024BYPASSED;
                        
                        Drv_WdtTimer_Start(1,CY_SYS_WDT_MODE_INT,NO_MODE);//60s WDT timer
                        Asw_Ble_SleepMode();
                    }
                    else{
                    
                        if(Drv_WdtTimer_isEnded()){
                            Drv_WdtTimer_Start(30,CY_SYS_WDT_MODE_RESET,NO_MODE);//reconfigure reset in 1min if problem
                            
                            _u16MainFlags &= ~FLAG_PH_ACQ;
                            ADC_Start();
                        	ADC_StartConvert();
                        	ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);

                            ph = ADC_GetResult16(ADC_PH_CHANNEL);
             
                            PH_switch_Write(SWITCH_OFF);
                            ADC_Stop();
                            ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_VDDA;  
                        }else{
                            Asw_Ble_SleepMode();
                        }

                    }
                    
                    
                   
                }
                
                
                /* Battery measure */
                else if((_u16MainFlags&FLAG_BATTERY) == FLAG_BATTERY){
                    _u16MainFlags &= ~FLAG_BATTERY;
                    battery = Hal_BatteryMeasure();
                }  
               
                else {
             
                        /* BLE device update */
                        if((_u16MainFlags&FLAG_BLE_DEVICE) == FLAG_BLE_DEVICE){
                            _u16MainFlags &= ~FLAG_BLE_DEVICE;
                            
                            Asw_Ble_UpdateBattery(battery);    
            
                            Asw_Ble_UpdateID();
                        }
                        else{ /* measure transfert */
                            

                             /* Measures Sigfox emission*/
                            if((_u16MainFlags&FLAG_SFX) > FLAG_NO_ACTIONS){
                            
                                if((_u16MainFlags&FLAG_SFX_INIT) == FLAG_SFX_INIT){

                                    _u16MainFlags &= ~FLAG_SFX_INIT;
                                    SIGFOX_EN_Write(SWITCH_ON);
                                    EN_TIMER_262MS();
                                }
                                else if((_u16MainFlags&FLAG_SFX_SEND) == FLAG_SFX_SEND){
                                    if(Hal_Counter_isEnded()){
                                        _u16MainFlags &= ~FLAG_SFX_SEND;
                                        TIMER_STOP();
                                        UART_rx_SetDriveMode(UART_rx_DM_RES_DWN);
                                        UART_tx_SetDriveMode(UART_tx_DM_RES_DWN);
                                        Hal_Uart_InitComm();
                                        Hal_Sfx_SendTrame(&battery, &conductivite, &temperature, &ph, &orp, &id_mesure);
                                        
                                        Drv_WdtTimer_Start(4,CY_SYS_WDT_MODE_INT,NO_MODE);//8s WDT timer
                                        CySysPmSleep();
                                       
                                    }
                                }else{
        
                                      if(Drv_WdtTimer_isEnded()){
                                        Drv_WdtTimer_Start(30,CY_SYS_WDT_MODE_RESET,NO_MODE);//reconfigure reset in 1min if problem
                                        _u16MainFlags &= ~FLAG_SFX_STOP;
                                        Hal_Uart_StopComm();
                                        UART_rx_SetDriveMode(UART_rx_DM_ALG_HIZ);
                                        UART_tx_SetDriveMode(UART_tx_DM_ALG_HIZ);
                                        
                                    }else{
                                        CySysPmSleep();
                                    }
                        
                                    
                                }
                            }
                        
                         /* BLE Measures update */
                        else if((_u16MainFlags&FLAG_BLE_MEASURE) == FLAG_BLE_MEASURE){
                            
                            _u16MainFlags &= ~FLAG_BLE_MEASURE;

                            Asw_Ble_UpdateMeasures(&battery, &conductivite, &temperature, &ph, &orp, &id_mesure);
                            
                        }
                        else{
                            _u16MainFlags &= ~FLAG_ALL_ACTIONS;
                        }
                    }
                    
             
                }

                
            }else{
                if(_u8MainInitSleep==0){
                    _u8MainInitSleep = 1;
                   
                    //Drv_WdtTimer_Start(WDT_COUNT1_MATCH_INT, CY_SYS_WDT_MODE_INT, MEASURES_MODE);
                    Drv_WdtTimer_Start(0x0001u, CY_SYS_WDT_MODE_INT, MEASURES_MODE);
                }
                modeOff();
                Asw_Ble_SleepMode();
                
                
            }

        
        }   
                       
    
    }   
        
    return 0;
}


//
///* [] END OF FILE */
//