/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file HAL_BATTERY.h
 * @brief BATTERY
 *
 *      Service to measure battery level
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include "HAL_BATTERY.h"

int32 Hal_BatteryMeasure(void)
{
	int16 adcResult;
    int32 mvolts;
	uint32 sarControlReg;
       
	/* Set the reference to VBG and enable reference bypass */
	sarControlReg = ADC_SAR_CTRL_REG & ~ADC_VREF_MASK;
	ADC_SAR_CTRL_REG = sarControlReg | ADC_VREF_INTERNAL1024BYPASSED;
	
	/* 25 ms delay for reference capacitor to charge */
	CyDelay(25);             
	
	/* Set the reference to VDD and disable reference bypass */
	sarControlReg = ADC_SAR_CTRL_REG & ~ADC_VREF_MASK;
	ADC_SAR_CTRL_REG = sarControlReg | ADC_VREF_VDDA;

	/* Perform a measurement. Store this value in Vref. */
	CyDelay(1);
    ADC_Start();
	ADC_StartConvert();
	ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);

    adcResult = ADC_GetResult16(ADC_BATT_CHANNEL);
    
	/* Calculate input voltage by using ratio of ADC counts from reference
	*  and ADC Full Scale counts. 
    */
	mvolts = (1024 * 2048) / adcResult;
    
    ADC_Stop();
    return mvolts;
}

/* [] END OF FILE */
