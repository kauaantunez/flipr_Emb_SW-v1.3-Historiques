/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file ASW_BLE.h
 * @brief BLE 
 *
 *      Applications to manage the stack events of BLE
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#ifndef ASW_BLE_H
#define ASW_BLE_H
    
#include <project.h>
#include "common.h"
#include "HAL_battery.h"
#include "HAL_DS18B20.h"
    

#define IMO_FREQUENCY_3MHZ			(3u)
#define IMO_FREQUENCY_12MHZ			(12u)
    

void Asw_Ble_StackEventHandler(uint32 event, void *eventParam);
void Asw_Ble_SleepMode(void);
void Asw_Ble_UpdateMode(uint8 * mode);
void Asw_Ble_UpdateMeasures(uint16 * battery, uint16 * conductivite, uint16 * temperature, uint16 * ph, uint16 * orp, uint16 * id_mesure);
void Asw_Ble_UpdateBattery(uint16 battery);
void Asw_Ble_UpdateID(void);
    
#endif    

/* [] END OF FILE */
