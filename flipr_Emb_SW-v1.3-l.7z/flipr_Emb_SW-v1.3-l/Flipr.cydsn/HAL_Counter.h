/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file HAL_Counter.h
 * @brief Counter 
 *
 *       Service for measure period from pin 2.4
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */
#ifndef HAL_COUNTER_H
#define HAL_COUNTER_H
    
#define COUNTER_STEP_US 1
    
#define EN_TIMER_7MS() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY1, COUNTER_INTR_MASK_CC_MATCH)
#define EN_TIMER_131MS() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY2, COUNTER_INTR_MASK_TC)
#define EN_TIMER_262MS() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY4, COUNTER_INTR_MASK_TC)
#define EN_TIMER_524MS() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY8, COUNTER_INTR_MASK_TC)
#define EN_TIMER_1S() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY16, COUNTER_INTR_MASK_TC)  
#define EN_TIMER_2S() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY32, COUNTER_INTR_MASK_TC)
#define EN_TIMER_4S() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY64, COUNTER_INTR_MASK_TC)
#define EN_TIMER_8S() Hal_Counter_Init(COUNTER_PRESCALE_DIVBY128, COUNTER_INTR_MASK_TC)
#define TIMER_END() Hal_Counter_isEnded()
#define TIMER_STOP() Hal_Counter_Stop()
    
#include <project.h>
#include "common.h"

CY_ISR(Counter_Int_Handler);
void Hal_Counter_Init(uint32 prescaler, uint32 int_mask);
uint8 Hal_Counter_isEnded(void);
void Hal_Counter_setPrescaler(uint32 value);
void Hal_Counter_Stop(void);

#endif
/* [] END OF FILE */
