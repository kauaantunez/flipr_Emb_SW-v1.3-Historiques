/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file ASW_BLE.h
 * @brief BLE 
 *
 *      This application manage the stack events of BLE
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include "ASW_BLE.h"
#include "HAL_UartSfx.h"

/* 'connectionHandle' stores connection parameters */
CYBLE_CONN_HANDLE_T  connectionHandle;
uint8 deviceConnected = 0;


void Asw_Ble_StackEventHandler(uint32 event, void *eventParam)
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
  
    switch(event)
    {
        /* Mandatory events*/
        case CYBLE_EVT_STACK_ON:
        CY_SET_XTND_REG32((void CYFAR *)(CYREG_BLE_BLERD_BB_XO_CAPTRIM), 0xBCBC);
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            /* Start BLE advertisement */
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);

            break;

        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            /* BLE link is established */
                
            break;

        case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            if(CyBle_GetState() == CYBLE_STATE_DISCONNECTED)
            {
                 CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
      
            }
            break;

        /**********************************************************
        *                       General Events
        ***********************************************************/
        case CYBLE_EVT_HARDWARE_ERROR:    /* This event indicates that some internal HW error has occurred. */
            break;

        case CYBLE_EVT_HCI_STATUS:
            break;

        /**********************************************************
        *                       GAP Events
        ***********************************************************/
        case CYBLE_EVT_GAP_AUTH_REQ:
            
            break;

        case CYBLE_EVT_GAP_PASSKEY_ENTRY_REQUEST:
            break;

        case CYBLE_EVT_GAP_PASSKEY_DISPLAY_REQUEST:
            break;

        case CYBLE_EVT_GAP_AUTH_COMPLETE:

            break;
        case CYBLE_EVT_GAP_AUTH_FAILED:

            break;

        case CYBLE_EVT_GAP_ENCRYPT_CHANGE:
            break;

        case CYBLE_EVT_GAPC_CONNECTION_UPDATE_COMPLETE:
            break;

        /**********************************************************
        *                       GATT Events
        ***********************************************************/
        case CYBLE_EVT_GATT_CONNECT_IND:
            /* This event is received when device is connected over GATT level */
            
			/* Update attribute handle on GATT Connection*/
            connectionHandle = *(CYBLE_CONN_HANDLE_T  *)eventParam;

			

			/* This flag is used in application to check connection status */
			deviceConnected = 1;
            
            
			break;

        case CYBLE_EVT_GATT_DISCONNECT_IND:
            deviceConnected = 0;
            break;

        case CYBLE_EVT_GATTS_XCNHG_MTU_REQ:
            break;

        case CYBLE_EVT_GATTS_READ_CHAR_VAL_ACCESS_REQ:
            
            break;
         
        case CYBLE_EVT_GATTS_WRITE_REQ:

              wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;

            
            if(CYBLE_DEVICE_DEVICE_MODE_CHAR_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
                _u8CommonMode = wrReqParam->handleValPair.value.val[0];
               
                if(_u8CommonMode == MODE_VEILLE){
                    CySysWdtWriteMode(CY_SYS_WDT_COUNTER1, CY_SYS_WDT_MODE_NONE);
                }
                else {
                    CySysWdtWriteMode(CY_SYS_WDT_COUNTER1, CY_SYS_WDT_MODE_INT);
                }
            }
            else if(CYBLE_DEVICE_DEVICE_ACQ_CHAR_HANDLE == wrReqParam->handleValPair.attrHandle)
            {
                _u16MainFlags |= FLAG_ALL_MEASURES;
                _u16MainFlags |= FLAG_BLE_DEVICE;
                _u16MainFlags |= FLAG_BLE_MEASURE;
            }
           
            CyBle_GattsWriteRsp(connectionHandle);
           
            
            
        break;

        /**********************************************************
        *                       Other Events
        ***********************************************************/
        case CYBLE_EVT_PENDING_FLASH_WRITE:
            break;

        default:
            break;
    }
}   



void Asw_Ble_SleepMode(){
    
    CYBLE_BLESS_STATE_T blessState;
    uint8 intrStatus;

    
    /* Configure BLESS in Deep-Sleep mode */
    CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
    
    /* Prevent interrupts while entering system low power modes */
    intrStatus = CyEnterCriticalSection();
    
    /* Get the current state of BLESS block */
    blessState = CyBle_GetBleSsState();
    
    /* If BLESS is in Deep-Sleep mode or the XTAL oscillator is turning on, 
     * then PSoC can enter Deep-Sleep mode (1.3uA current consumption) */
    if(blessState == CYBLE_BLESS_STATE_ECO_ON || 
        blessState == CYBLE_BLESS_STATE_DEEPSLEEP)
    {
        CySysPmDeepSleep();
    }
    else if(blessState != CYBLE_BLESS_STATE_EVENT_CLOSE)
    {
        /* If BLESS is active, then configure PSoC BLE system in 
         * Sleep mode (~1.6mA current consumption) */
         CySysPmSleep();
    }

    CyExitCriticalSection(intrStatus);
    
    /* BLE link layer timing interrupt will wake up the system from Sleep 
     * and Deep-Sleep modes */
}

void Asw_Ble_UpdateMeasures(uint16 * battery, uint16 * conductivite, uint16 * temperature, uint16 * ph, uint16 * orp, uint16 * id_mesure)
{
    CYBLE_GATT_ERR_CODE_T apiGattErrCode = 0;
    CYBLE_GATT_HANDLE_VALUE_PAIR_T    handleValuePair;
    
    ACQFRAME sMeasures = {
    GET_LSB(*temperature),  GET_MSB(*temperature),
    GET_LSB(*ph),  GET_MSB(*ph),
    GET_LSB(*orp),  GET_MSB(*orp),
    GET_LSB(*conductivite),  GET_MSB(*conductivite),
    1,
    GET_LSB(*id_mesure),  GET_MSB(*id_mesure),
    GET_LSB(*battery),  GET_MSB(*battery)};
    
    handleValuePair.value.val = (uint8 * )&sMeasures;
    handleValuePair.value.len = sizeof(sMeasures);
    handleValuePair.attrHandle = CYBLE_MEASURES_MEASURES_CHARACTERISTIC_CHAR_HANDLE;
      
    /* To register the service change in the Database of the GATT Server */
    apiGattErrCode = CyBle_GattsWriteAttributeValue(&handleValuePair, 0u, NULL,CYBLE_GATT_DB_LOCALLY_INITIATED);


}

void Asw_Ble_UpdateBattery(uint16 battery)
{
    CYBLE_GATT_ERR_CODE_T apiGattErrCode = 0;
    CYBLE_GATT_HANDLE_VALUE_PAIR_T    handleValuePair;
    
   
    handleValuePair.value.val = (uint8 * )&battery;
    handleValuePair.value.len = sizeof(battery);
    handleValuePair.attrHandle = CYBLE_DEVICE_DEVICE_BATTERY_CHAR_HANDLE;
      
    /* To register the service change in the Database of the GATT Server */
    apiGattErrCode = CyBle_GattsWriteAttributeValue(&handleValuePair, 0u, NULL,CYBLE_GATT_DB_LOCALLY_INITIATED);


}

void Asw_Ble_UpdateID(void)
{
    CYBLE_GATT_ERR_CODE_T apiGattErrCode = 0;
    CYBLE_GATT_HANDLE_VALUE_PAIR_T    handleValuePair;
    uint8 id[4] = {1,3,2,1};
    
   
    handleValuePair.value.val = (uint8 * )&id;
    handleValuePair.value.len = sizeof(id);
    handleValuePair.attrHandle = CYBLE_DEVICE_DEVICE_INFORMATION_CHAR_HANDLE;
      
    /* To register the service change in the Database of the GATT Server */
    apiGattErrCode = CyBle_GattsWriteAttributeValue(&handleValuePair, 0u, NULL,CYBLE_GATT_DB_LOCALLY_INITIATED);

}

/* [] END OF FILE */
