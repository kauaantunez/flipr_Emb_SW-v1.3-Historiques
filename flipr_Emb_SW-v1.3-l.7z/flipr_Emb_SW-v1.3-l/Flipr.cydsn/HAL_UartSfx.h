/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file ASW_Sfx.h
 * @brief Sfx 
 *
 *      Services for communication Sigfox
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#ifndef ASW_UartSfx_H
#define ASW_UartSfx_H
    
#include <project.h>
#include "common.h"
#include <stdio.h>
    
#define MAX_CH 50

    
void Hal_Uart_InitComm(void);
void Hal_Uart_StopComm(void);
void Hal_Sfx_ReadId(uint8 ch[8]);
void Hal_Sfx_ReadPac(uint8 ch[16]);
void Hal_Uart_Read(uint8 ch[MAX_CH]);
void Hal_Uart_WaitForData(void);
void Hal_Sfx_SendTrame(uint16 * battery, uint16 * conductivite, uint16 * temperature, uint16 * ph, uint16 * orp, uint16 * id_mesure);
CY_ISR( UART_Int_Handler ); 

#endif
/* [] END OF FILE */
