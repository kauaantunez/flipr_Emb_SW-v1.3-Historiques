/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file common.h
 * @brief Common 
 *
 *       Common defines and variables. 
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include <project.h>
#include <string.h>

#ifndef COMMON_H
#define COMMON_H

#define MODE_NORMAL 1
#define MODE_VEILLE 0
    
#define ADC_PH_CHANNEL              (0x00u)
#define ADC_ORP_CHANNEL             (0x01u)
#define ADC_BATT_CHANNEL             (0x02u)
    
#define ADC_VREF_MASK               (0x000000F0Lu)
    
#define WDT_COUNT0_MATCH    (0xFFFFu)
#define WDT_COUNT1_MATCH_INT    (0x0708u)
#define WDT_COUNT1_MATCH_RESET    (0x0078u)
    
#define LED_ON                      (0u)
#define LED_OFF                     (1u)

#define SWITCH_OFF                    (0u)
#define SWITCH_ON                     (1u)

#define FLAG_TEMPERATURE_ACQ 0x01
#define FLAG_TEMPERATURE_INIT 0x02
#define FLAG_TEMPERATURE_READ 0x04
#define FLAG_TEMPERATURE (FLAG_TEMPERATURE_READ|FLAG_TEMPERATURE_ACQ|FLAG_TEMPERATURE_INIT)

#define FLAG_PH_ACQ 0x08
#define FLAG_PH_INIT 0x10
#define FLAG_PH (FLAG_PH_ACQ|FLAG_PH_INIT)

#define FLAG_CONDT_ACQ 0x020
#define FLAG_CONDT_INIT 0x40
#define FLAG_CONDT (FLAG_CONDT_ACQ|FLAG_CONDT_INIT)

#define FLAG_ORP_ACQ 0x80
#define FLAG_ORP_INIT 0x100
#define FLAG_ORP (FLAG_ORP_ACQ|FLAG_ORP_INIT)

#define FLAG_BATTERY 0x200

#define FLAG_SFX_INIT 0x400
#define FLAG_SFX_SEND 0x800
#define FLAG_SFX_STOP 0x1000
#define FLAG_SFX (FLAG_SFX_INIT|FLAG_SFX_SEND|FLAG_SFX_STOP)

#define FLAG_BLE_MEASURE 0x2000
#define FLAG_BLE_DEVICE 0x4000

    
#define FLAG_NO_ACTIONS 0x0
#define FLAG_ALL_ACTIONS 0xFFFF
#define FLAG_ALL_MEASURES (FLAG_TEMPERATURE|FLAG_PH|FLAG_CONDT|FLAG_ORP|FLAG_BATTERY)

#define CLEAR_WATCHDOG() CySysWdtResetCounters(CY_SYS_WDT_COUNTER1_RESET|CY_SYS_WDT_COUNTER0_RESET)
    
#define ADC_BATTERY_CHANNEL         (0x00u)

#define COMPARE(a,b) strcmp(a,b)==0?1:0
#define STARTWITH(a,b) (strncmp(b,a,strlen(b))==0)?1:0

#define POWER_ANALOGIQUE    (0x01u)
#define POWER_SIGFOX    (0x02u)
#define POWER_TEMPERATURE (0x04u)
    
#define NO_MODE 0
#define MEASURES_MODE 1

typedef struct
{
    
    uint8 Temp_lsb;
    uint8 Temp_msb;
    
    uint8 PH_lsb;
    uint8 PH_msb;
    
    uint8 ORP_lsb;
    uint8 ORP_msb;
    
    uint8 Condt_lsb;
    uint8 Condt_msb;
    
    uint8 Mode;
    
    uint8 ID_lsb;
    uint8 ID_msb;
    
    uint8 Batt_lsb;
    uint8 Batt_msb;
    
} ACQFRAME;

#define GET_MSB(n) ((n>>8)&0x00FF)
#define GET_LSB(n) ((n&0x00FF))

extern volatile uint8 _u8CommonMode;
extern volatile uint16 _u16MainFlags;

void modeOff();

#endif



/* [] END OF FILE */
