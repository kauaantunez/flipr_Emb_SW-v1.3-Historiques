/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file DRV_OneWire.h
 * @brief OneWire
 *
 *      Drivers for comunication bus 1-Wire
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

    
#ifndef DRV_ONEWIRE_H
#define DRV_ONEWIRE_H


#include "cytypes.h"        
#include <project.h>
#include "common.h"

#define Tinact  20          //in us. (Inactive before next signal)
#define TMtr0   50          //Data bit 0 read,write 15-60us
#define TMtr1   10          //Data bit 1 read,write 1-15us
#define RST_MAX 480         //in us


uint8 OneWire_R_Bit();                 //******   ReadBit ************

void OneWire_W_Bit(uint8 payload);     //******   WriteBit ***********

uint8 OneWire_BusReset();              //******** Bus Reset **********

void OneWire_Write8(uint8 payload);    //******* Write a byte *********

uint8 OneWire_Read8();           //******* Read a byte *********


#endif

/* [] END OF FILE */
