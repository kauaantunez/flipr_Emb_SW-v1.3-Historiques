/*******************************************************************************
* File Name: PH_switch.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PH_switch_ALIASES_H) /* Pins PH_switch_ALIASES_H */
#define CY_PINS_PH_switch_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define PH_switch_0			(PH_switch__0__PC)
#define PH_switch_0_PS		(PH_switch__0__PS)
#define PH_switch_0_PC		(PH_switch__0__PC)
#define PH_switch_0_DR		(PH_switch__0__DR)
#define PH_switch_0_SHIFT	(PH_switch__0__SHIFT)
#define PH_switch_0_INTR	((uint16)((uint16)0x0003u << (PH_switch__0__SHIFT*2u)))

#define PH_switch_INTR_ALL	 ((uint16)(PH_switch_0_INTR))


#endif /* End Pins PH_switch_ALIASES_H */


/* [] END OF FILE */
