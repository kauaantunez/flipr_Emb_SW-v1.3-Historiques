/*******************************************************************************
* File Name: ORP_switch.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ORP_switch_ALIASES_H) /* Pins ORP_switch_ALIASES_H */
#define CY_PINS_ORP_switch_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define ORP_switch_0			(ORP_switch__0__PC)
#define ORP_switch_0_PS		(ORP_switch__0__PS)
#define ORP_switch_0_PC		(ORP_switch__0__PC)
#define ORP_switch_0_DR		(ORP_switch__0__DR)
#define ORP_switch_0_SHIFT	(ORP_switch__0__SHIFT)
#define ORP_switch_0_INTR	((uint16)((uint16)0x0003u << (ORP_switch__0__SHIFT*2u)))

#define ORP_switch_INTR_ALL	 ((uint16)(ORP_switch_0_INTR))


#endif /* End Pins ORP_switch_ALIASES_H */


/* [] END OF FILE */
