/*******************************************************************************
* File Name: COUNTER.h
* Version 2.10
*
* Description:
*  This file provides constants and parameter values for the COUNTER
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_COUNTER_H)
#define CY_TCPWM_COUNTER_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} COUNTER_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  COUNTER_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define COUNTER_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define COUNTER_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define COUNTER_CONFIG                         (1lu)

/* Quad Mode */
/* Parameters */
#define COUNTER_QUAD_ENCODING_MODES            (0lu)
#define COUNTER_QUAD_AUTO_START                (1lu)

/* Signal modes */
#define COUNTER_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define COUNTER_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define COUNTER_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define COUNTER_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define COUNTER_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define COUNTER_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define COUNTER_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define COUNTER_TC_RUN_MODE                    (0lu)
#define COUNTER_TC_COUNTER_MODE                (0lu)
#define COUNTER_TC_COMP_CAP_MODE               (2lu)
#define COUNTER_TC_PRESCALER                   (0lu)

/* Signal modes */
#define COUNTER_TC_RELOAD_SIGNAL_MODE          (0lu)
#define COUNTER_TC_COUNT_SIGNAL_MODE           (3lu)
#define COUNTER_TC_START_SIGNAL_MODE           (0lu)
#define COUNTER_TC_STOP_SIGNAL_MODE            (0lu)
#define COUNTER_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define COUNTER_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define COUNTER_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define COUNTER_TC_START_SIGNAL_PRESENT        (0lu)
#define COUNTER_TC_STOP_SIGNAL_PRESENT         (0lu)
#define COUNTER_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define COUNTER_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define COUNTER_PWM_KILL_EVENT                 (0lu)
#define COUNTER_PWM_STOP_EVENT                 (0lu)
#define COUNTER_PWM_MODE                       (4lu)
#define COUNTER_PWM_OUT_N_INVERT               (0lu)
#define COUNTER_PWM_OUT_INVERT                 (0lu)
#define COUNTER_PWM_ALIGN                      (0lu)
#define COUNTER_PWM_RUN_MODE                   (0lu)
#define COUNTER_PWM_DEAD_TIME_CYCLE            (0lu)
#define COUNTER_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define COUNTER_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define COUNTER_PWM_COUNT_SIGNAL_MODE          (3lu)
#define COUNTER_PWM_START_SIGNAL_MODE          (0lu)
#define COUNTER_PWM_STOP_SIGNAL_MODE           (0lu)
#define COUNTER_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define COUNTER_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define COUNTER_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define COUNTER_PWM_START_SIGNAL_PRESENT       (0lu)
#define COUNTER_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define COUNTER_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define COUNTER_PWM_INTERRUPT_MASK             (1lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define COUNTER_TC_PERIOD_VALUE                (65535lu)
#define COUNTER_TC_COMPARE_VALUE               (65535lu)
#define COUNTER_TC_COMPARE_BUF_VALUE           (65535lu)
#define COUNTER_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define COUNTER_PWM_PERIOD_VALUE               (65535lu)
#define COUNTER_PWM_PERIOD_BUF_VALUE           (65535lu)
#define COUNTER_PWM_PERIOD_SWAP                (0lu)
#define COUNTER_PWM_COMPARE_VALUE              (65535lu)
#define COUNTER_PWM_COMPARE_BUF_VALUE          (65535lu)
#define COUNTER_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define COUNTER__LEFT 0
#define COUNTER__RIGHT 1
#define COUNTER__CENTER 2
#define COUNTER__ASYMMETRIC 3

#define COUNTER__X1 0
#define COUNTER__X2 1
#define COUNTER__X4 2

#define COUNTER__PWM 4
#define COUNTER__PWM_DT 5
#define COUNTER__PWM_PR 6

#define COUNTER__INVERSE 1
#define COUNTER__DIRECT 0

#define COUNTER__CAPTURE 2
#define COUNTER__COMPARE 0

#define COUNTER__TRIG_LEVEL 3
#define COUNTER__TRIG_RISING 0
#define COUNTER__TRIG_FALLING 1
#define COUNTER__TRIG_BOTH 2

#define COUNTER__INTR_MASK_TC 1
#define COUNTER__INTR_MASK_CC_MATCH 2
#define COUNTER__INTR_MASK_NONE 0
#define COUNTER__INTR_MASK_TC_CC 3

#define COUNTER__UNCONFIG 8
#define COUNTER__TIMER 1
#define COUNTER__QUAD 3
#define COUNTER__PWM_SEL 7

#define COUNTER__COUNT_UP 0
#define COUNTER__COUNT_DOWN 1
#define COUNTER__COUNT_UPDOWN0 2
#define COUNTER__COUNT_UPDOWN1 3


/* Prescaler */
#define COUNTER_PRESCALE_DIVBY1                ((uint32)(0u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY2                ((uint32)(1u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY4                ((uint32)(2u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY8                ((uint32)(3u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY16               ((uint32)(4u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY32               ((uint32)(5u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY64               ((uint32)(6u << COUNTER_PRESCALER_SHIFT))
#define COUNTER_PRESCALE_DIVBY128              ((uint32)(7u << COUNTER_PRESCALER_SHIFT))

/* TCPWM set modes */
#define COUNTER_MODE_TIMER_COMPARE             ((uint32)(COUNTER__COMPARE         <<  \
                                                                  COUNTER_MODE_SHIFT))
#define COUNTER_MODE_TIMER_CAPTURE             ((uint32)(COUNTER__CAPTURE         <<  \
                                                                  COUNTER_MODE_SHIFT))
#define COUNTER_MODE_QUAD                      ((uint32)(COUNTER__QUAD            <<  \
                                                                  COUNTER_MODE_SHIFT))
#define COUNTER_MODE_PWM                       ((uint32)(COUNTER__PWM             <<  \
                                                                  COUNTER_MODE_SHIFT))
#define COUNTER_MODE_PWM_DT                    ((uint32)(COUNTER__PWM_DT          <<  \
                                                                  COUNTER_MODE_SHIFT))
#define COUNTER_MODE_PWM_PR                    ((uint32)(COUNTER__PWM_PR          <<  \
                                                                  COUNTER_MODE_SHIFT))

/* Quad Modes */
#define COUNTER_MODE_X1                        ((uint32)(COUNTER__X1              <<  \
                                                                  COUNTER_QUAD_MODE_SHIFT))
#define COUNTER_MODE_X2                        ((uint32)(COUNTER__X2              <<  \
                                                                  COUNTER_QUAD_MODE_SHIFT))
#define COUNTER_MODE_X4                        ((uint32)(COUNTER__X4              <<  \
                                                                  COUNTER_QUAD_MODE_SHIFT))

/* Counter modes */
#define COUNTER_COUNT_UP                       ((uint32)(COUNTER__COUNT_UP        <<  \
                                                                  COUNTER_UPDOWN_SHIFT))
#define COUNTER_COUNT_DOWN                     ((uint32)(COUNTER__COUNT_DOWN      <<  \
                                                                  COUNTER_UPDOWN_SHIFT))
#define COUNTER_COUNT_UPDOWN0                  ((uint32)(COUNTER__COUNT_UPDOWN0   <<  \
                                                                  COUNTER_UPDOWN_SHIFT))
#define COUNTER_COUNT_UPDOWN1                  ((uint32)(COUNTER__COUNT_UPDOWN1   <<  \
                                                                  COUNTER_UPDOWN_SHIFT))

/* PWM output invert */
#define COUNTER_INVERT_LINE                    ((uint32)(COUNTER__INVERSE         <<  \
                                                                  COUNTER_INV_OUT_SHIFT))
#define COUNTER_INVERT_LINE_N                  ((uint32)(COUNTER__INVERSE         <<  \
                                                                  COUNTER_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define COUNTER_TRIG_RISING                    ((uint32)COUNTER__TRIG_RISING)
#define COUNTER_TRIG_FALLING                   ((uint32)COUNTER__TRIG_FALLING)
#define COUNTER_TRIG_BOTH                      ((uint32)COUNTER__TRIG_BOTH)
#define COUNTER_TRIG_LEVEL                     ((uint32)COUNTER__TRIG_LEVEL)

/* Interrupt mask */
#define COUNTER_INTR_MASK_TC                   ((uint32)COUNTER__INTR_MASK_TC)
#define COUNTER_INTR_MASK_CC_MATCH             ((uint32)COUNTER__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define COUNTER_CC_MATCH_SET                   (0x00u)
#define COUNTER_CC_MATCH_CLEAR                 (0x01u)
#define COUNTER_CC_MATCH_INVERT                (0x02u)
#define COUNTER_CC_MATCH_NO_CHANGE             (0x03u)
#define COUNTER_OVERLOW_SET                    (0x00u)
#define COUNTER_OVERLOW_CLEAR                  (0x04u)
#define COUNTER_OVERLOW_INVERT                 (0x08u)
#define COUNTER_OVERLOW_NO_CHANGE              (0x0Cu)
#define COUNTER_UNDERFLOW_SET                  (0x00u)
#define COUNTER_UNDERFLOW_CLEAR                (0x10u)
#define COUNTER_UNDERFLOW_INVERT               (0x20u)
#define COUNTER_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define COUNTER_PWM_MODE_LEFT                  (COUNTER_CC_MATCH_CLEAR        |   \
                                                         COUNTER_OVERLOW_SET           |   \
                                                         COUNTER_UNDERFLOW_NO_CHANGE)
#define COUNTER_PWM_MODE_RIGHT                 (COUNTER_CC_MATCH_SET          |   \
                                                         COUNTER_OVERLOW_NO_CHANGE     |   \
                                                         COUNTER_UNDERFLOW_CLEAR)
#define COUNTER_PWM_MODE_ASYM                  (COUNTER_CC_MATCH_INVERT       |   \
                                                         COUNTER_OVERLOW_SET           |   \
                                                         COUNTER_UNDERFLOW_CLEAR)

#if (COUNTER_CY_TCPWM_V2)
    #if(COUNTER_CY_TCPWM_4000)
        #define COUNTER_PWM_MODE_CENTER                (COUNTER_CC_MATCH_INVERT       |   \
                                                                 COUNTER_OVERLOW_NO_CHANGE     |   \
                                                                 COUNTER_UNDERFLOW_CLEAR)
    #else
        #define COUNTER_PWM_MODE_CENTER                (COUNTER_CC_MATCH_INVERT       |   \
                                                                 COUNTER_OVERLOW_SET           |   \
                                                                 COUNTER_UNDERFLOW_CLEAR)
    #endif /* (COUNTER_CY_TCPWM_4000) */
#else
    #define COUNTER_PWM_MODE_CENTER                (COUNTER_CC_MATCH_INVERT       |   \
                                                             COUNTER_OVERLOW_NO_CHANGE     |   \
                                                             COUNTER_UNDERFLOW_CLEAR)
#endif /* (COUNTER_CY_TCPWM_NEW) */

/* Command operations without condition */
#define COUNTER_CMD_CAPTURE                    (0u)
#define COUNTER_CMD_RELOAD                     (8u)
#define COUNTER_CMD_STOP                       (16u)
#define COUNTER_CMD_START                      (24u)

/* Status */
#define COUNTER_STATUS_DOWN                    (1u)
#define COUNTER_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   COUNTER_Init(void);
void   COUNTER_Enable(void);
void   COUNTER_Start(void);
void   COUNTER_Stop(void);

void   COUNTER_SetMode(uint32 mode);
void   COUNTER_SetCounterMode(uint32 counterMode);
void   COUNTER_SetPWMMode(uint32 modeMask);
void   COUNTER_SetQDMode(uint32 qdMode);

void   COUNTER_SetPrescaler(uint32 prescaler);
void   COUNTER_TriggerCommand(uint32 mask, uint32 command);
void   COUNTER_SetOneShot(uint32 oneShotEnable);
uint32 COUNTER_ReadStatus(void);

void   COUNTER_SetPWMSyncKill(uint32 syncKillEnable);
void   COUNTER_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   COUNTER_SetPWMDeadTime(uint32 deadTime);
void   COUNTER_SetPWMInvert(uint32 mask);

void   COUNTER_SetInterruptMode(uint32 interruptMask);
uint32 COUNTER_GetInterruptSourceMasked(void);
uint32 COUNTER_GetInterruptSource(void);
void   COUNTER_ClearInterrupt(uint32 interruptMask);
void   COUNTER_SetInterrupt(uint32 interruptMask);

void   COUNTER_WriteCounter(uint32 count);
uint32 COUNTER_ReadCounter(void);

uint32 COUNTER_ReadCapture(void);
uint32 COUNTER_ReadCaptureBuf(void);

void   COUNTER_WritePeriod(uint32 period);
uint32 COUNTER_ReadPeriod(void);
void   COUNTER_WritePeriodBuf(uint32 periodBuf);
uint32 COUNTER_ReadPeriodBuf(void);

void   COUNTER_WriteCompare(uint32 compare);
uint32 COUNTER_ReadCompare(void);
void   COUNTER_WriteCompareBuf(uint32 compareBuf);
uint32 COUNTER_ReadCompareBuf(void);

void   COUNTER_SetPeriodSwap(uint32 swapEnable);
void   COUNTER_SetCompareSwap(uint32 swapEnable);

void   COUNTER_SetCaptureMode(uint32 triggerMode);
void   COUNTER_SetReloadMode(uint32 triggerMode);
void   COUNTER_SetStartMode(uint32 triggerMode);
void   COUNTER_SetStopMode(uint32 triggerMode);
void   COUNTER_SetCountMode(uint32 triggerMode);

void   COUNTER_SaveConfig(void);
void   COUNTER_RestoreConfig(void);
void   COUNTER_Sleep(void);
void   COUNTER_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define COUNTER_BLOCK_CONTROL_REG              (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define COUNTER_BLOCK_CONTROL_PTR              ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define COUNTER_COMMAND_REG                    (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define COUNTER_COMMAND_PTR                    ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define COUNTER_INTRRUPT_CAUSE_REG             (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define COUNTER_INTRRUPT_CAUSE_PTR             ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define COUNTER_CONTROL_REG                    (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__CTRL )
#define COUNTER_CONTROL_PTR                    ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__CTRL )
#define COUNTER_STATUS_REG                     (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__STATUS )
#define COUNTER_STATUS_PTR                     ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__STATUS )
#define COUNTER_COUNTER_REG                    (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__COUNTER )
#define COUNTER_COUNTER_PTR                    ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__COUNTER )
#define COUNTER_COMP_CAP_REG                   (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__CC )
#define COUNTER_COMP_CAP_PTR                   ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__CC )
#define COUNTER_COMP_CAP_BUF_REG               (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__CC_BUFF )
#define COUNTER_COMP_CAP_BUF_PTR               ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__CC_BUFF )
#define COUNTER_PERIOD_REG                     (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__PERIOD )
#define COUNTER_PERIOD_PTR                     ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__PERIOD )
#define COUNTER_PERIOD_BUF_REG                 (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define COUNTER_PERIOD_BUF_PTR                 ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define COUNTER_TRIG_CONTROL0_REG              (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define COUNTER_TRIG_CONTROL0_PTR              ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define COUNTER_TRIG_CONTROL1_REG              (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define COUNTER_TRIG_CONTROL1_PTR              ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define COUNTER_TRIG_CONTROL2_REG              (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define COUNTER_TRIG_CONTROL2_PTR              ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define COUNTER_INTERRUPT_REQ_REG              (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR )
#define COUNTER_INTERRUPT_REQ_PTR              ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR )
#define COUNTER_INTERRUPT_SET_REG              (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR_SET )
#define COUNTER_INTERRUPT_SET_PTR              ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR_SET )
#define COUNTER_INTERRUPT_MASK_REG             (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR_MASK )
#define COUNTER_INTERRUPT_MASK_PTR             ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR_MASK )
#define COUNTER_INTERRUPT_MASKED_REG           (*(reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR_MASKED )
#define COUNTER_INTERRUPT_MASKED_PTR           ( (reg32 *) COUNTER_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define COUNTER_MASK                           ((uint32)COUNTER_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define COUNTER_RELOAD_CC_SHIFT                (0u)
#define COUNTER_RELOAD_PERIOD_SHIFT            (1u)
#define COUNTER_PWM_SYNC_KILL_SHIFT            (2u)
#define COUNTER_PWM_STOP_KILL_SHIFT            (3u)
#define COUNTER_PRESCALER_SHIFT                (8u)
#define COUNTER_UPDOWN_SHIFT                   (16u)
#define COUNTER_ONESHOT_SHIFT                  (18u)
#define COUNTER_QUAD_MODE_SHIFT                (20u)
#define COUNTER_INV_OUT_SHIFT                  (20u)
#define COUNTER_INV_COMPL_OUT_SHIFT            (21u)
#define COUNTER_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define COUNTER_RELOAD_CC_MASK                 ((uint32)(COUNTER_1BIT_MASK        <<  \
                                                                            COUNTER_RELOAD_CC_SHIFT))
#define COUNTER_RELOAD_PERIOD_MASK             ((uint32)(COUNTER_1BIT_MASK        <<  \
                                                                            COUNTER_RELOAD_PERIOD_SHIFT))
#define COUNTER_PWM_SYNC_KILL_MASK             ((uint32)(COUNTER_1BIT_MASK        <<  \
                                                                            COUNTER_PWM_SYNC_KILL_SHIFT))
#define COUNTER_PWM_STOP_KILL_MASK             ((uint32)(COUNTER_1BIT_MASK        <<  \
                                                                            COUNTER_PWM_STOP_KILL_SHIFT))
#define COUNTER_PRESCALER_MASK                 ((uint32)(COUNTER_8BIT_MASK        <<  \
                                                                            COUNTER_PRESCALER_SHIFT))
#define COUNTER_UPDOWN_MASK                    ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                            COUNTER_UPDOWN_SHIFT))
#define COUNTER_ONESHOT_MASK                   ((uint32)(COUNTER_1BIT_MASK        <<  \
                                                                            COUNTER_ONESHOT_SHIFT))
#define COUNTER_QUAD_MODE_MASK                 ((uint32)(COUNTER_3BIT_MASK        <<  \
                                                                            COUNTER_QUAD_MODE_SHIFT))
#define COUNTER_INV_OUT_MASK                   ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                            COUNTER_INV_OUT_SHIFT))
#define COUNTER_MODE_MASK                      ((uint32)(COUNTER_3BIT_MASK        <<  \
                                                                            COUNTER_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define COUNTER_CAPTURE_SHIFT                  (0u)
#define COUNTER_COUNT_SHIFT                    (2u)
#define COUNTER_RELOAD_SHIFT                   (4u)
#define COUNTER_STOP_SHIFT                     (6u)
#define COUNTER_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define COUNTER_CAPTURE_MASK                   ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                  COUNTER_CAPTURE_SHIFT))
#define COUNTER_COUNT_MASK                     ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                  COUNTER_COUNT_SHIFT))
#define COUNTER_RELOAD_MASK                    ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                  COUNTER_RELOAD_SHIFT))
#define COUNTER_STOP_MASK                      ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                  COUNTER_STOP_SHIFT))
#define COUNTER_START_MASK                     ((uint32)(COUNTER_2BIT_MASK        <<  \
                                                                  COUNTER_START_SHIFT))

/* MASK */
#define COUNTER_1BIT_MASK                      ((uint32)0x01u)
#define COUNTER_2BIT_MASK                      ((uint32)0x03u)
#define COUNTER_3BIT_MASK                      ((uint32)0x07u)
#define COUNTER_6BIT_MASK                      ((uint32)0x3Fu)
#define COUNTER_8BIT_MASK                      ((uint32)0xFFu)
#define COUNTER_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define COUNTER_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define COUNTER_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(COUNTER_QUAD_ENCODING_MODES     << COUNTER_QUAD_MODE_SHIFT))       |\
         ((uint32)(COUNTER_CONFIG                  << COUNTER_MODE_SHIFT)))

#define COUNTER_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(COUNTER_PWM_STOP_EVENT          << COUNTER_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(COUNTER_PWM_OUT_INVERT          << COUNTER_INV_OUT_SHIFT))         |\
         ((uint32)(COUNTER_PWM_OUT_N_INVERT        << COUNTER_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(COUNTER_PWM_MODE                << COUNTER_MODE_SHIFT)))

#define COUNTER_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(COUNTER_PWM_RUN_MODE         << COUNTER_ONESHOT_SHIFT))
            
#define COUNTER_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(COUNTER_PWM_ALIGN            << COUNTER_UPDOWN_SHIFT))

#define COUNTER_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(COUNTER_PWM_KILL_EVENT      << COUNTER_PWM_SYNC_KILL_SHIFT))

#define COUNTER_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(COUNTER_PWM_DEAD_TIME_CYCLE  << COUNTER_PRESCALER_SHIFT))

#define COUNTER_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(COUNTER_PWM_PRESCALER        << COUNTER_PRESCALER_SHIFT))

#define COUNTER_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(COUNTER_TC_PRESCALER            << COUNTER_PRESCALER_SHIFT))       |\
         ((uint32)(COUNTER_TC_COUNTER_MODE         << COUNTER_UPDOWN_SHIFT))          |\
         ((uint32)(COUNTER_TC_RUN_MODE             << COUNTER_ONESHOT_SHIFT))         |\
         ((uint32)(COUNTER_TC_COMP_CAP_MODE        << COUNTER_MODE_SHIFT)))
        
#define COUNTER_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(COUNTER_QUAD_PHIA_SIGNAL_MODE   << COUNTER_COUNT_SHIFT))           |\
         ((uint32)(COUNTER_QUAD_INDEX_SIGNAL_MODE  << COUNTER_RELOAD_SHIFT))          |\
         ((uint32)(COUNTER_QUAD_STOP_SIGNAL_MODE   << COUNTER_STOP_SHIFT))            |\
         ((uint32)(COUNTER_QUAD_PHIB_SIGNAL_MODE   << COUNTER_START_SHIFT)))

#define COUNTER_PWM_SIGNALS_MODES                                                              \
        (((uint32)(COUNTER_PWM_SWITCH_SIGNAL_MODE  << COUNTER_CAPTURE_SHIFT))         |\
         ((uint32)(COUNTER_PWM_COUNT_SIGNAL_MODE   << COUNTER_COUNT_SHIFT))           |\
         ((uint32)(COUNTER_PWM_RELOAD_SIGNAL_MODE  << COUNTER_RELOAD_SHIFT))          |\
         ((uint32)(COUNTER_PWM_STOP_SIGNAL_MODE    << COUNTER_STOP_SHIFT))            |\
         ((uint32)(COUNTER_PWM_START_SIGNAL_MODE   << COUNTER_START_SHIFT)))

#define COUNTER_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(COUNTER_TC_CAPTURE_SIGNAL_MODE  << COUNTER_CAPTURE_SHIFT))         |\
         ((uint32)(COUNTER_TC_COUNT_SIGNAL_MODE    << COUNTER_COUNT_SHIFT))           |\
         ((uint32)(COUNTER_TC_RELOAD_SIGNAL_MODE   << COUNTER_RELOAD_SHIFT))          |\
         ((uint32)(COUNTER_TC_STOP_SIGNAL_MODE     << COUNTER_STOP_SHIFT))            |\
         ((uint32)(COUNTER_TC_START_SIGNAL_MODE    << COUNTER_START_SHIFT)))
        
#define COUNTER_TIMER_UPDOWN_CNT_USED                                                          \
                ((COUNTER__COUNT_UPDOWN0 == COUNTER_TC_COUNTER_MODE)                  ||\
                 (COUNTER__COUNT_UPDOWN1 == COUNTER_TC_COUNTER_MODE))

#define COUNTER_PWM_UPDOWN_CNT_USED                                                            \
                ((COUNTER__CENTER == COUNTER_PWM_ALIGN)                               ||\
                 (COUNTER__ASYMMETRIC == COUNTER_PWM_ALIGN))               
        
#define COUNTER_PWM_PR_INIT_VALUE              (1u)
#define COUNTER_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_COUNTER_H */

/* [] END OF FILE */
