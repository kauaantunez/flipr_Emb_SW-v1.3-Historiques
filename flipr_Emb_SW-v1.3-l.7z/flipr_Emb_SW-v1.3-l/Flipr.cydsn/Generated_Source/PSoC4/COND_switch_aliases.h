/*******************************************************************************
* File Name: COND_switch.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_COND_switch_ALIASES_H) /* Pins COND_switch_ALIASES_H */
#define CY_PINS_COND_switch_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define COND_switch_0			(COND_switch__0__PC)
#define COND_switch_0_PS		(COND_switch__0__PS)
#define COND_switch_0_PC		(COND_switch__0__PC)
#define COND_switch_0_DR		(COND_switch__0__DR)
#define COND_switch_0_SHIFT	(COND_switch__0__SHIFT)
#define COND_switch_0_INTR	((uint16)((uint16)0x0003u << (COND_switch__0__SHIFT*2u)))

#define COND_switch_INTR_ALL	 ((uint16)(COND_switch_0_INTR))


#endif /* End Pins COND_switch_ALIASES_H */


/* [] END OF FILE */
