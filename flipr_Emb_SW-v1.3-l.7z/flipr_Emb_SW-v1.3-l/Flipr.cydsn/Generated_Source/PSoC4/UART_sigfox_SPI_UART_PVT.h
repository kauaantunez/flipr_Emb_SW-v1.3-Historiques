/***************************************************************************//**
* \file UART_sigfox_SPI_UART_PVT.h
* \version 3.20
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_UART_sigfox_H)
#define CY_SCB_SPI_UART_PVT_UART_sigfox_H

#include "UART_sigfox_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if (UART_sigfox_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  UART_sigfox_rxBufferHead;
    extern volatile uint32  UART_sigfox_rxBufferTail;
    
    /**
    * \addtogroup group_globals
    * @{
    */
    
    /** Sets when internal software receive buffer overflow
     *  was occurred.
    */  
    extern volatile uint8   UART_sigfox_rxBufferOverflow;
    /** @} globals */
#endif /* (UART_sigfox_INTERNAL_RX_SW_BUFFER_CONST) */

#if (UART_sigfox_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  UART_sigfox_txBufferHead;
    extern volatile uint32  UART_sigfox_txBufferTail;
#endif /* (UART_sigfox_INTERNAL_TX_SW_BUFFER_CONST) */

#if (UART_sigfox_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 UART_sigfox_rxBufferInternal[UART_sigfox_INTERNAL_RX_BUFFER_SIZE];
#endif /* (UART_sigfox_INTERNAL_RX_SW_BUFFER) */

#if (UART_sigfox_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 UART_sigfox_txBufferInternal[UART_sigfox_TX_BUFFER_SIZE];
#endif /* (UART_sigfox_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

void UART_sigfox_SpiPostEnable(void);
void UART_sigfox_SpiStop(void);

#if (UART_sigfox_SCB_MODE_SPI_CONST_CFG)
    void UART_sigfox_SpiInit(void);
#endif /* (UART_sigfox_SCB_MODE_SPI_CONST_CFG) */

#if (UART_sigfox_SPI_WAKE_ENABLE_CONST)
    void UART_sigfox_SpiSaveConfig(void);
    void UART_sigfox_SpiRestoreConfig(void);
#endif /* (UART_sigfox_SPI_WAKE_ENABLE_CONST) */

void UART_sigfox_UartPostEnable(void);
void UART_sigfox_UartStop(void);

#if (UART_sigfox_SCB_MODE_UART_CONST_CFG)
    void UART_sigfox_UartInit(void);
#endif /* (UART_sigfox_SCB_MODE_UART_CONST_CFG) */

#if (UART_sigfox_UART_WAKE_ENABLE_CONST)
    void UART_sigfox_UartSaveConfig(void);
    void UART_sigfox_UartRestoreConfig(void);
#endif /* (UART_sigfox_UART_WAKE_ENABLE_CONST) */


/***************************************
*         UART API Constants
***************************************/

/* UART RX and TX position to be used in UART_sigfox_SetPins() */
#define UART_sigfox_UART_RX_PIN_ENABLE    (UART_sigfox_UART_RX)
#define UART_sigfox_UART_TX_PIN_ENABLE    (UART_sigfox_UART_TX)

/* UART RTS and CTS position to be used in  UART_sigfox_SetPins() */
#define UART_sigfox_UART_RTS_PIN_ENABLE    (0x10u)
#define UART_sigfox_UART_CTS_PIN_ENABLE    (0x20u)


/***************************************
* The following code is DEPRECATED and
* must not be used.
***************************************/

/* Interrupt processing */
#define UART_sigfox_SpiUartEnableIntRx(intSourceMask)  UART_sigfox_SetRxInterruptMode(intSourceMask)
#define UART_sigfox_SpiUartEnableIntTx(intSourceMask)  UART_sigfox_SetTxInterruptMode(intSourceMask)
uint32  UART_sigfox_SpiUartDisableIntRx(void);
uint32  UART_sigfox_SpiUartDisableIntTx(void);


#endif /* (CY_SCB_SPI_UART_PVT_UART_sigfox_H) */


/* [] END OF FILE */
