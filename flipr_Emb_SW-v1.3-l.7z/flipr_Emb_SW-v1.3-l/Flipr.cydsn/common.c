/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file common.h
 * @brief Common 
 *
 *       Common defines and variables. 
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */

#include "common.h"

volatile uint8 _u8CommonMode = MODE_NORMAL;
volatile uint16 _u16MainFlags = FLAG_NO_ACTIONS;

void modeOff(){
    ANALOG_EN_Write(SWITCH_OFF);
    EN_TEMP_Write(SWITCH_OFF);
    PH_switch_Write(SWITCH_OFF);

    COND_switch_Write(SWITCH_OFF);
    ORP_switch_Write(SWITCH_OFF);
    SIGFOX_EN_Write(SWITCH_OFF);

    UART_rx_SetDriveMode(UART_rx_DM_ALG_HIZ);
    UART_tx_SetDriveMode(UART_tx_DM_ALG_HIZ);
    Pin_TEMP_SetDriveMode(Pin_TEMP_DM_ALG_HIZ);
    Pin_condt_SetDriveMode(Pin_condt_DM_ALG_HIZ);
    Pin_TestMode_SetDriveMode(Pin_TestMode_DM_ALG_HIZ);
    
    ADC_Stop();
    UART_Stop();
    COUNTER_Stop();
}



/* [] END OF FILE */
