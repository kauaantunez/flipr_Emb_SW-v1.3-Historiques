/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file DRV_Sleep.h
 * @brief Sleep
 *
 *      Drivers for sleep mode
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */
#ifndef DRV_WDT_TIMER_H
#define DRV_WDT_TIMER_H


#include "cytypes.h"        
#include <project.h>
#include "common.h"
    
void Drv_WdtTimer_Start(uint16 delay, uint8 mode, uint8 config);
uint8_t Drv_WdtTimer_isEnded(void);
#endif

/* [] END OF FILE */
