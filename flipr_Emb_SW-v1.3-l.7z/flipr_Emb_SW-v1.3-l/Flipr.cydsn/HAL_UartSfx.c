/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file ASW_Sfx.h
 * @brief Sfx 
 *
 *      Services for communication Sigfox
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */
#include "HAL_UartSfx.h"

uint8 _ch[MAX_CH];
uint8 _size=0;
volatile uint8 _read=0;

volatile uint8_t _i=0;

CY_ISR( UART_Int_Handler ){
    
    uint32 intSource = UART_GetRxInterruptSource();
    
    if((intSource & UART_INTR_RX_NOT_EMPTY) != 0){
        char ch = UART_UartGetChar();

        if (0u != ch)
        {
            _ch[_i++] = ch;
            
            if('\r' == ch){
                _read=1;
                _size=_i-1;
                _i=0;
            }
        }
        
        UART_ClearRxInterruptSource(UART_INTR_RX_NOT_EMPTY);
        
    }
}

void Hal_Sfx_ReadId(uint8 ch[8]){
    uint8 i=0;
    _i=0;
    UART_UartPutString("AT$I=10\r\n");
    while(_i==0){}
    while(_i!=0){}
    for(i=0;i<8;i++){
        ch[i] = _ch[i];
    }
}

void Hal_Sfx_ReadPac(uint8 ch[16]){
    uint8 i=0;
    _i=0;
    UART_UartPutString("AT$I=11\r\n"); 
    while(_i==0){}
    while(_i!=0){}
    for(i=0;i<16;i++){
        ch[i] = _ch[i];
    }
}

void Hal_Uart_WaitForData(){
    while(_read==0){} 
}

void Hal_Uart_Read(uint8 ch[MAX_CH]){
    uint8 i=0;
    
    
    
    _read=0;
    
    for(i=0;i<MAX_CH;i++){
        ch[i] = _ch[i];
    }
}


void Hal_Uart_InitComm(void){
    
    /* UART init */
    UART_Init();
    UART_Start();
    _read=0;
    _i=0;
    /* Start interrupt */
    UART_INT_StartEx(UART_Int_Handler);
}

void Hal_Uart_StopComm(void){
     /* Disable alimentation Sigfox */ 
    SIGFOX_EN_Write(SWITCH_OFF);
    
    /* Stop UART for Sigfox */
    UART_Stop();
    
    /* Stop interrupt */
    UART_INT_Stop();
}


void Hal_Sfx_SendTrame(uint16 * battery, uint16 * conductivite, uint16 * temperature, uint16 * ph, uint16 * orp, uint16 * id_mesure){
     uint8 cmd_sigfox[32] = "AT$SF=FFFFFFFFFFFFFFFFFFFFFFFF\r\n"; 
    
    sprintf(cmd_sigfox, "AT$SF=%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x\r\n", 
        GET_LSB(*temperature),  GET_MSB(*temperature),
        GET_LSB(*ph),  GET_MSB(*ph),
        GET_LSB(*orp),  GET_MSB(*orp),
        GET_LSB(*conductivite), GET_MSB(*conductivite),
        GET_LSB(*id_mesure), GET_MSB(*id_mesure),
        GET_LSB(*battery), GET_MSB(*battery));
    
    UART_UartPutString((char * ) cmd_sigfox); // send Frame Sigfox
}

/* [] END OF FILE */
