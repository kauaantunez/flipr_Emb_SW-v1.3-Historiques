/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file ASW_TestMode.h
 * @brief Test Mode
 *
 *      Applications to manage the test mode for the test bench
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 16 Mar 2017
 */

#include "ASW_TestMode.h"
#include "HAL_UartSfx.h"
#include "HAL_DS18B20.h"
#include "HAL_BATTERY.h"
#include "HAL_Counter.h"
#include "ASW_BLE.h"
#include "DRV_WdtTimer.h"

uint16 _u16MainFreqOrp;

CY_ISR(Condt_Test_Int_Handler){
    Pin_condt_ClearInterrupt();
    _u16MainFreqOrp+=1;
}


void Asw_TestMode_Start(void){
    uint8 state = 0;
    uint8 id[8] = {0};
    uint8 pac[16] = {0};
    uint8 ch[32] = {0};
    uint8 end = 0;
    uint16 temperature = 0;
    uint16 orp = 0;
    uint16 ph = 0;
    uint16 conductivite = 0;
    int8 rep[20] = {0};
    uint8 device_name[20] = {0};
    uint8 i=0;
    
    CySysClkEcoStop();
    
    
    UART_rx_SetDriveMode(UART_rx_DM_RES_DWN);
    UART_tx_SetDriveMode(UART_tx_DM_RES_DWN);

    CyBle_Stop();
    
    while(end==0){
        Hal_Uart_InitComm();   
        CySysPmSleep();
        Hal_Uart_WaitForData();
        Hal_Uart_Read(ch);
        Hal_Uart_StopComm();

        if(STARTWITH((const char *) ch,":WRITE_U_ALIM=")){
            if(ch[9]=='1'){
                ANALOG_EN_Write(SWITCH_ON);
            }else{
                ANALOG_EN_Write(SWITCH_OFF);
            }
            
            if(ch[11]=='1'){
                SIGFOX_EN_Write(SWITCH_ON);
            }else{
                SIGFOX_EN_Write(SWITCH_OFF);
            }
            
             if(ch[13]=='1'){
                EN_TEMP_Write(SWITCH_ON);
            }else{
                EN_TEMP_Write(SWITCH_OFF);
            }

            sprintf(rep, ":WRITE_U=ok\n\r");
        }
        else if(STARTWITH((const char *) ch, ":WRITE_U_SLEEP")){
            modeOff();
            Drv_WdtTimer_Start(3, CY_SYS_WDT_MODE_INT, NO_MODE);

            CySysPmDeepSleep();
            UART_Start();
            UART_rx_SetDriveMode(UART_rx_DM_RES_DWN);
            UART_tx_SetDriveMode(UART_tx_DM_RES_DWN);
            WdtIsr_Stop();
            CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK | CY_SYS_WDT_COUNTER1_MASK);
            
            sprintf(rep, ":WRITE_U_SLEEP=end\n\r");

        }
        else if(STARTWITH((const char *) ch, ":WRITE_U_ID")){
            for(i=0;ch[i]!='\r';i++){
                device_name[i] = ch[12+i]; 
            }
            device_name[i+1] = '\0';
            CyBle_GapSetLocalName(device_name);
            sprintf(rep, ":WRITE_U_ID=ok\n\r");
        }
        else if(STARTWITH((const char *) ch,":READ_U_TEMP")){

           /* DO TEMPERATURE MEASURE */
            Hal_DS18_doAcq();
            CyDelay(2000);
            temperature = Hal_DS18_ReadTemp();

            sprintf(rep, ":READ_U_TEMP=%d\n\r", temperature);
        }else if(STARTWITH((const char *) ch,":READ_U_ORP")){
           /* DO ORP MESURE */
            PH_switch_Write(SWITCH_OFF);
            ORP_switch_Write(SWITCH_ON);
            ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_INTERNAL1024;
            
            ADC_Start();
        	ADC_StartConvert();
        	ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    
            orp = ADC_GetResult16(ADC_ORP_CHANNEL);

            ORP_switch_Write(SWITCH_OFF);
            ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_VDDA;  
            ADC_Stop();
            sprintf(rep, ":READ_U_ORP=%d\n\r", orp);
        }else if(STARTWITH((const char *) ch,":READ_U_PH")){
            
           /* DO PH MESURE */
            ADC_Start();
            ORP_switch_Write(SWITCH_OFF);
            PH_switch_Write(SWITCH_ON);
       
            ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_INTERNAL1024BYPASSED;

            ADC_StartConvert();
            ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);

            ph = ADC_GetResult16(ADC_PH_CHANNEL);

            PH_switch_Write(SWITCH_OFF);
            ADC_Stop();
            ADC_SAR_CTRL_REG = (ADC_SAR_CTRL_REG & ~ADC_VREF_MASK) | ADC_VREF_VDDA;  
            sprintf(rep, ":READ_U_PH=%d\n\r", ph);
        }else if(STARTWITH((const char *) ch,":READ_U_CONDT")){
           /* DO CONDUCTIVITE MESURE */
            COND_switch_Write(SWITCH_ON);
            _u16MainFreqOrp=0;
            Int_condt_StartEx(Condt_Test_Int_Handler);
            Pin_condt_SetDriveMode(Pin_condt_DM_RES_DWN);
            
            EN_TIMER_1S();
            while(TIMER_END()==0){}
            Int_condt_Stop();
            conductivite = (uint16_t) _u16MainFreqOrp/1.04856;
            COND_switch_Write(SWITCH_OFF);
            Pin_condt_SetDriveMode(Pin_condt_DM_DIG_HIZ);
            TIMER_STOP();
            sprintf(rep, ":READ_U_CONDT=%d\n\r", conductivite);
        }
        else if(STARTWITH((const char *) ch,":READ_U_SFXID")){
           /* READ SIGFOX ID */

            ANALOG_EN_Write(SWITCH_ON);
            SIGFOX_EN_Write(SWITCH_ON);
            CyDelay(200);
            
            Drv_WdtTimer_Start(2, CY_SYS_WDT_MODE_RESET, NO_MODE);
            
            Hal_Uart_InitComm();     
            Hal_Sfx_ReadId(id);
            Hal_Uart_StopComm();
            
            ANALOG_EN_Write(SWITCH_OFF);
            SIGFOX_EN_Write(SWITCH_OFF);
            
            
            
            CLEAR_WATCHDOG();
            WdtIsr_Stop();
            CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK | CY_SYS_WDT_COUNTER1_MASK);
            
            sprintf(rep, ":READ_U_SFXID=%1c%1c%1c%1c%1c%1c%1c%1c\n\r", id[0],id[1],id[2],id[3],id[4],id[5],id[6],id[7]);
            
        }
        else if(STARTWITH((const char *) ch,":READ_U_SFXPAC")){
           /* READ SIGFOX PAC */
            ANALOG_EN_Write(SWITCH_ON);
            SIGFOX_EN_Write(SWITCH_ON);
            CyDelay(200);
            Drv_WdtTimer_Start(2, CY_SYS_WDT_MODE_RESET, NO_MODE);
            Hal_Uart_InitComm();
            Hal_Sfx_ReadPac(pac);
            
            Hal_Uart_StopComm();
            
            ANALOG_EN_Write(SWITCH_OFF);
            SIGFOX_EN_Write(SWITCH_OFF);
            
            
            
            CLEAR_WATCHDOG();
            WdtIsr_Stop();
            CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK | CY_SYS_WDT_COUNTER1_MASK);
            
            sprintf(rep, ":READ_U_SFXPAC=%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c\n\r", 
                pac[0],pac[1],pac[2],pac[3],pac[4],pac[5],pac[6],pac[7],
            pac[8],pac[9],pac[10],pac[11],pac[12],pac[13],pac[14],pac[15]);
        }
        else if(STARTWITH((const char *) ch, ":WRITE_U_SFXSF")){
            ANALOG_EN_Write(SWITCH_ON);
            SIGFOX_EN_Write(SWITCH_ON);
            CyDelay(200);
            Hal_Uart_InitComm();
            UART_UartPutString("AT$SF=000000000000000000000000\r\n"); // send Frame Sigfox
            EN_TIMER_4S();
            while(TIMER_END()==0){}
            TIMER_STOP();
            Hal_Uart_StopComm();
            ANALOG_EN_Write(SWITCH_OFF);
            SIGFOX_EN_Write(SWITCH_OFF);
            sprintf(rep, ":WRITE_U_SFXSF=ok\n\r");
        }
        else if(STARTWITH((const char *) ch, ":WRITE_U_SFXCW")){
            ANALOG_EN_Write(SWITCH_ON);
            SIGFOX_EN_Write(SWITCH_ON);
            CyDelay(200);
            Hal_Uart_InitComm();
            UART_UartPutString("AT$CW=868130000,1\r\n"); // send Frame Sigfox
            EN_TIMER_4S();
            while(TIMER_END()==0){}
            TIMER_STOP();
            Hal_Uart_StopComm();
            ANALOG_EN_Write(SWITCH_OFF);
            SIGFOX_EN_Write(SWITCH_OFF);
            sprintf(rep, ":WRITE_U_SFXCW=ok\n\r");
        }
        else if(STARTWITH((const char *) ch,":WRITE_U_END")){
            end=1;
            sprintf(rep, ":WRITE_U_END=ok\n\r");
        }
        else{
            sprintf(rep, "?UNKNOW_FRAME\n\r");
        }
     
        

        Hal_Uart_InitComm();
        UART_UartPutString(rep);
        CyDelay(100);
        Hal_Uart_StopComm();

    }
    
    ADC_Stop();
    UART_Stop();
  
    UART_rx_SetDriveMode(UART_rx_DM_ALG_HIZ);
    UART_tx_SetDriveMode(UART_tx_DM_ALG_HIZ);
    
    CySysClkEcoStart(0);
}

/* [] END OF FILE */
