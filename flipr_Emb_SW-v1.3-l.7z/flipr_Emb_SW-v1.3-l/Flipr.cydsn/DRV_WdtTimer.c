/**
 * Copyright (C) 2017 Axible
 * This SOFTWARE belong exclusively to Axible Technologies and is confidential.
 * Redistribution and use in source and/or binary forms, with or without
 * modification, are totally prohibited without Axible Technologies written approval
 *
 * @file DRV_WdtTimer.h
 * @brief Watchdog Timer
 *
 *      Drivers for watchdog timer
 *
 * @author Thomas Cayrou
 * @version 1.0
 * @date 02 Feb 2017
 */
#include "Drv_WdtTimer.h"

uint8_t _isEnded;
uint8_t _config;

CY_ISR(WdtIsrHandler)
{
    /* Clear interrupts state */
	CySysWdtClearInterrupt(CY_SYS_WDT_COUNTER1_INT);
    WdtIsr_ClearPending();

    if(_config==MEASURES_MODE){
        /* DO ALL MEASURES AND SIGFOX TRANSMISSION */
        _u16MainFlags |=  FLAG_ALL_MEASURES|FLAG_SFX;
        _u16MainFlags |=  FLAG_BLE_MEASURE|FLAG_BLE_DEVICE;

        
        Drv_WdtTimer_Start(WDT_COUNT1_MATCH_RESET, CY_SYS_WDT_MODE_RESET, NO_MODE);
    }
    
    _isEnded=1;

}

void Drv_WdtTimer_Start(uint16 delay, uint8 mode, uint8 config){
    _isEnded=0;
    _config=config;
    CySysWdtUnlock();
                   
    CySysWdtDisable(CY_SYS_WDT_COUNTER0_MASK | CY_SYS_WDT_COUNTER1_MASK);
    
    CLEAR_WATCHDOG();
    
    /* Set WDT counter 0 as timer base */
    CySysWdtWriteMode(CY_SYS_WDT_COUNTER0, CY_SYS_WDT_MODE_NONE);
    CySysWdtWriteMatch(CY_SYS_WDT_COUNTER0, WDT_COUNT0_MATCH);
    CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER0, 1u);

	/* Enable WDT counters 0 and 1 cascade */
	CySysWdtWriteCascade(CY_SYS_WDT_CASCADE_01);
    
	/* Set WDT counter 1 to generate interrupt on match */
	CySysWdtWriteMatch(CY_SYS_WDT_COUNTER1,  delay);
	CySysWdtWriteMode(CY_SYS_WDT_COUNTER1, mode);
    CySysWdtWriteClearOnMatch(CY_SYS_WDT_COUNTER1, 1u);


    /* Enable WDT counters 0 and 1 */
    CySysWdtEnable(CY_SYS_WDT_COUNTER0_MASK | CY_SYS_WDT_COUNTER1_MASK);
    
    if(WdtIsr_GetState()==0){
        WdtIsr_StartEx(WdtIsrHandler);
    }
}

uint8_t Drv_WdtTimer_isEnded(void){
    return _isEnded;
}

/* [] END OF FILE */
